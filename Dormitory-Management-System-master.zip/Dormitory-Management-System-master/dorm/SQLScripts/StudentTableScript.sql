CREATE TABLE mppproject.student(
  studentId INT NOT NULL,
  studentName VARCHAR(45) NULL,
  studentEmail VARCHAR(45) NULL
 );