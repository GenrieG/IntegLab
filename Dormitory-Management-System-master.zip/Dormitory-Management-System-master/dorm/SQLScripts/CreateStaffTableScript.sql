CREATE TABLE `mppproject`.`staff` (
  `staffId` INT NOT NULL,
  `staffName` VARCHAR(45) NOT NULL,
  `staffEmail` VARCHAR(45) NOT NULL);