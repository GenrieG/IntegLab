CREATE TABLE roomallocate(
  buildingNo INT NOT NULL,
  roomNo INT NOT NULL,
  studentId INT NOT NULL);