package groupseven.mppproject.utils;

public enum FormType {
	CHECKIN,
	CHECKOUT
}
