package groupseven.mppproject.utils;

public enum ForumType {
	Suggestion,
	Complain,
	Maintainance
}