package groupseven.mppproject.businesslogic.interfaces;

import java.sql.SQLException;

public interface ImySQL {
	public void create();
}
