package groupseven.mppproject.businesslogic.interfaces;

public interface IPerson {
   void getPersonInfo(int id);
}
