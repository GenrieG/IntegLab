package groupseven.mppproject.exceptions;

public class FormException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FormException() {
		super();
	}

	public FormException(String msg) {
		super(msg);
	}
}
